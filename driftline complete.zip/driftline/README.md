# Driftline

Early scammer detection for online marketplaces.

---

## What's in here

```
driftline/
  api/          → Python backend (FastAPI)
  dashboard/    → Trust & Safety dashboard (HTML)
  landing/      → Marketing site (HTML)
```

---

## Deploy the API on Railway (free)

1. Go to railway.app and create a free account
2. Click "New Project" → "Deploy from GitHub"
   - OR click "New Project" → "Empty Project" → drag the /api folder
3. Railway auto-detects Python and installs requirements.txt
4. Your API goes live at a URL like: https://driftline-api.railway.app
5. Copy that URL

---

## Connect the dashboard to your API

1. Open dashboard/index.html
2. Find this line near the bottom:
   const API_URL = ... 'https://your-api.railway.app'
3. Replace 'https://your-api.railway.app' with your real Railway URL
4. Save the file

---

## Deploy the dashboard + landing page on Netlify (free)

1. Go to netlify.com/drop
2. Drag the /landing folder in → get your landing page URL
3. Drag the /dashboard folder in → get your dashboard URL

---

## How a marketplace integrates with you

Tell their engineer to add this to their messaging system:

```python
import requests

# Call this every time a user sends a message
def track_message(user_id, conversation_id):
    requests.post("https://your-api.railway.app/event", json={
        "user_id": user_id,
        "platform": "their_platform_name",
        "conversation_id": conversation_id,
    })
```

That's the entire integration on their end.

---

## API Endpoints

POST /event          → Track a message event, get risk score back
GET  /score/{id}     → Get current risk score for a user
GET  /flagged        → Get all flagged accounts (used by dashboard)
GET  /stats          → Platform stats
DELETE /account/{id} → Mark account as reviewed/suspended
GET  /docs           → Interactive API docs (auto-generated)

---

## Test it locally

```
cd api
pip install -r requirements.txt
uvicorn main:app --reload
```

Then open: http://localhost:8000/docs

---

Built by Leo Cohen · Driftline · trydriftline.com
